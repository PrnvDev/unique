<?php

namespace TheGem_Elementor\Widgets\TemplatePostTitle;

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;

if (!defined('ABSPATH')) exit;

/**
 * Elementor widget for Blog Title.
 */

#[\AllowDynamicProperties]
class TheGem_TemplatePostTitle extends Widget_Base {
	public function __construct($data = [], $args = null) {

		$template_type = isset($GLOBALS['thegem_template_type']) ? $GLOBALS['thegem_template_type'] : thegem_get_template_type(get_the_ID());
		$this->is_loop_builder_template = false; //$template_type === 'loop-item';

		if (isset($data['settings']) && (empty($_REQUEST['action']) || !in_array($_REQUEST['action'], array('thegem_importer_process', 'thegem_templates_new', 'thegem_blocks_import')))) {
			if (!isset($data['settings']['text_tag'])) {
				if ($this->is_loop_builder_template) {
					$data['settings']['text_tag'] = 'div';
				} else {
					$data['settings']['text_tag'] = 'h1';
				}
			}

			if (!isset($data['settings']['text_style'])) {
				if ($this->is_loop_builder_template) {
					$data['settings']['text_style'] = 'title-h4';
				} else {
					$data['settings']['text_style'] = '';
				}
			}

			if (!isset($data['settings']['text_transform'])) {
				if ($this->is_loop_builder_template) {
					$data['settings']['text_transform'] = 'none';
				} else {
					$data['settings']['text_transform'] = 'default';
				}
			}

			if (!isset($data['settings']['text_letter_spacing'])) {
				if ($this->is_loop_builder_template) {
					$data['settings']['text_letter_spacing']['size'] = 0;
					$data['settings']['text_letter_spacing']['unit'] = 'px';
				} else {
					$data['settings']['text_letter_spacing']['size'] = 2.5;
					$data['settings']['text_letter_spacing']['unit'] = 'px';
				}
			}

			if (!isset($data['settings']['link'])) {
				if ($this->is_loop_builder_template) {
					$data['settings']['link'] = 'post';
				} else {
					$data['settings']['link'] = 'none';
				}
			}

		}

		parent::__construct($data, $args);
	}

	/**
	 * Retrieve the widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'thegem-template-post-title';
	}

	/**
	 * Show in panel.
	 *
	 * Whether to show the widget in the panel or not. By default returns true.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return bool Whether to show the widget in the panel or not.
	 */
	public function show_in_panel() {
		return get_post_type() !== 'thegem_templates' || thegem_get_template_type(get_the_id()) === 'single-post' || thegem_get_template_type(get_the_id()) === 'loop-item' || thegem_get_template_type(get_the_id()) === 'title';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		if(get_post_type() === 'thegem_templates' && thegem_get_template_type(get_the_id()) === 'loop-item') {
			return __('Post/Product Title', 'thegem');
		}
		return __('Post Title', 'thegem');
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return str_replace('thegem-', 'thegem-eicon thegem-eicon-', $this->get_name());
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		if(get_post_type() === 'thegem_templates' && thegem_get_template_type(get_the_id()) === 'loop-item') return ['thegem_loop_builder'];
		if(get_post_type() === 'thegem_templates' && thegem_get_template_type(get_the_id()) === 'title') return ['thegem_title_area_builder'];
		if(get_post_type() === 'thegem_templates') return ['thegem_single_post_builder'];
		return ['thegem_single_post'];
	}

	/** Show reload button */
	public function is_reload_preview_required() {
		return true;
	}

	/** Get widget wrapper */
	public function get_widget_wrapper() {
		return 'thegem-te-post-title';
	}

	/** Get customize class */
	public function get_customize_class($only_parent = false) {
		if ($only_parent) {
			return ' .'.$this->get_widget_wrapper();
		}

		return ' .'.$this->get_widget_wrapper().' .post-title';
	}

	/**
	 * Register the widget controls.
	 *
	 * @access protected
	 */
	protected function register_controls() {

		// General Section
		$this->start_controls_section(
			'section_general',
			[
				'label' => __('General', 'thegem'),
			]
		);

		$this->add_control(
			'alignment',
			[
				'label' => __('Alignment', 'thegem'),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __('Left', 'thegem'),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'thegem'),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __('Right', 'thegem'),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __('Justified', 'thegem'),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => 'left',
				'selectors_dictionary' => [
					'left' => 'justify-content: left; text-align: left;',
					'right' => 'justify-content: right; text-align: right;',
					'center' => 'justify-content: center; text-align: center;',
					'justify' => 'justify-content: space-between; text-align: justify;',
				],
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class(true) => '{{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_tag',
			[
				'label' => __('HTML Tag', 'thegem'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => __('H1', 'thegem'),
					'h2' => __('H2', 'thegem'),
					'h3' => __('H3', 'thegem'),
					'h4' => __('H4', 'thegem'),
					'h5' => __('H5', 'thegem'),
					'h6' => __('H6', 'thegem'),
					'p' => __('p', 'thegem'),
					'div' => __('div', 'thegem'),
				],
				'default' => $this->is_loop_builder_template ? 'div' : 'h1',
			]
		);

		$this->add_control(
			'text_style',
			[
				'label' => __('Text Style', 'thegem'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'' => __('Default', 'thegem'),
					'title-h1' => __('Title H1', 'thegem'),
					'title-h2' => __('Title H2', 'thegem'),
					'title-h3' => __('Title H3', 'thegem'),
					'title-h4' => __('Title H4', 'thegem'),
					'title-h5' => __('Title H5', 'thegem'),
					'title-h6' => __('Title H6', 'thegem'),
					'title-xlarge' => __('Title xLarge', 'thegem'),
					'styled-subtitle' => __('Styled Subtitle', 'thegem'),
					'title-main-menu' => __('Main Menu', 'thegem'),
					'title-text-body' => __('Body', 'thegem'),
					'title-text-body-tiny' => __('Tiny Body', 'thegem'),
				],
				'default' => $this->is_loop_builder_template ? 'title-h4' : '',
			]
		);

		$this->add_control(
			'text_weight',
			[
				'label' => __('Font weight', 'thegem'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'' => __('Default', 'thegem'),
					'light' => __('Thin', 'thegem'),
				],
				'default' => '',
			]
		);

		$this->add_control(
			'text_letter_spacing',
			[
				'label' => __('Letter Spacing', 'thegem'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px', '%', 'rem', 'em'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => 0.5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'rem' => [
						'min' => 0,
						'max' => 100,
					],
					'em' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'size' => $this->is_loop_builder_template ? 0 : 2.5,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class() => 'letter-spacing: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __('Text Transform', 'thegem'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'default' => __('Default', 'thegem'),
					'none' => __('None', 'thegem'),
					'capitalize' => __('Capitalize', 'thegem'),
					'lowercase' => __('Lowercase', 'thegem'),
					'uppercase' => __('Uppercase', 'thegem'),
				],
				'default' => $this->is_loop_builder_template ? 'none' : 'default',
				'selectors_dictionary' => [
					'default' => '',
					'none' => 'text-transform: none;',
					'capitalize' => 'text-transform: capitalize;',
					'lowercase' => 'text-transform: lowercase;',
					'uppercase' => 'text-transform: uppercase;',
				],
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class() => '{{VALUE}};',
				],
			]
		);

		$this->add_control(
			'truncate_title',
			[
				'label' => __('Truncate Title (Lines)', 'thegem'),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 10,
				'step' => 1,
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class().' span' => 'max-height: initial; white-space: initial; display: -webkit-box; -webkit-line-clamp: {{VALUE}}; line-clamp: {{VALUE}}; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis;',
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __('Link', 'thegem'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => __('None', 'thegem'),
					'post' => __('Page/Post Url', 'thegem'),
					'custom' => __('Custom', 'thegem'),
				],
				'separator' => 'before',
				'default' => $this->is_loop_builder_template ? 'post' : 'none',
			]
		);

		$this->add_control(
			'link_custom',
			[
				'label' => __('Custom Link', 'thegem'),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => '',
				],
				'condition' => [
					'link' => 'custom',
				],
			]
		);

		$this->end_controls_section();

		// Style Section
		$this->start_controls_section(
			'Style',
			[
				'label' => __('Style', 'thegem'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'selector' => '{{WRAPPER}}'.$this->get_customize_class(),
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '{{WRAPPER}}'.$this->get_customize_class(),
			]
		);

		$this->add_control(
			'max_width',
			[
				'label' => __('Max Width', 'thegem'),
				'type' => Controls_Manager::TEXT,
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class() => 'max-width: {{VALUE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'separator_bottom_spacing',
			[
				'label' => __('Bottom Spacing', 'thegem'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class() => 'margin-bottom:{{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __('Text Color', 'thegem'),
				'type' => Controls_Manager::COLOR,
				'label_block' => false,
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class() => 'color: {{VALUE}};',
					'{{WRAPPER}}'.$this->get_customize_class().' a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_color_hover',
			[
				'label' => __('Text Color Hover', 'thegem'),
				'type' => Controls_Manager::COLOR,
				'label_block' => false,
				'selectors' => [
					'{{WRAPPER}}'.$this->get_customize_class().' a:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'link' => ['post', 'custom'],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	public function render() {
		$settings = $this->get_settings_for_display();
		$params = array_merge(array(), $settings);

		ob_start();
		$single_post = thegem_templates_init_post();

		if (empty($single_post)) {
			ob_end_clean();
			echo thegem_templates_close_post(str_replace('-template-', '-te-', $this->get_name()), $this->get_title(), '');
			return;
		}

		$is_link = false;
		if (isset($params['link']) && $params['link'] != 'none') {
			switch ($params['link']) {
				case 'post':
					$is_link = true;
					$this->add_render_attribute('a-wrapper', 'href', get_permalink($single_post));
					$this->add_render_attribute('a-wrapper', 'target', '_self');

					break;
				case 'custom':
					if (!empty($params['link_custom']['url'])) {
						$is_link = true;
						$this->add_render_attribute('a-wrapper', 'href', $params['link_custom']['url']);

						if (!empty($params['link_custom']['is_external'])) {
							$this->add_render_attribute('a-wrapper', 'target', '_blank');
						}

						if (!empty($params['link_custom']['nofollow'])) {
							$this->add_render_attribute('a-wrapper', 'rel', 'nofollow');
						}
					}

					break;
			}
		}

		$params['element_class'] = implode(' ', array($this->get_widget_wrapper()));
		$text_styled_class = implode(' ', array($params['text_style'], $params['text_weight']));

		?>

        <div class="<?= esc_attr($params['element_class']); ?>">
			<<?= $params['text_tag'] ?> class="post-title <?= $text_styled_class ?>">
				<?php if ($is_link): ?><a <?= $this->get_render_attribute_string( 'a-wrapper' ); ?>><?php endif; ?>
					<span><?= get_the_title($single_post); ?></span>
				<?php if ($is_link): ?></a><?php endif; ?>
			</<?= $params['text_tag'] ?>>
        </div>

		<?php

		$return_html = trim(preg_replace('/\s\s+/', ' ', ob_get_clean()));

		echo thegem_templates_close_post(str_replace('-template-', '-te-', $this->get_name()), $this->get_title(), $return_html);
	}
}

\Elementor\Plugin::instance()->widgets_manager->register(new TheGem_TemplatePostTitle());
