<?php

require_once(plugin_dir_path( __FILE__ ) . 'widgets.php');