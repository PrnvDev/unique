<?php

require_once(plugin_dir_path( __FILE__ ) . 'shortcodes.php');
require_once(plugin_dir_path( __FILE__ ) . 'woo-shortcodes.php');
//require_once(plugin_dir_path( __FILE__ ) . 'shortcodes-generator.php');