(function ($) {

    'use strict';

    const $account = $('.thegem-te-account');

    const accountScripts = {
        init: () => {
            console.log('account')
        },
    }

    // Run the function
    $(function () {
        accountScripts.init();
    });
})(jQuery);