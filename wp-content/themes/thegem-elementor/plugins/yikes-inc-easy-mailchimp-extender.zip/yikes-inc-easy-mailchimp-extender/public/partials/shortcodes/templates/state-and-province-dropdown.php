<option data-country="US" value="">---</option>
<option data-country="US" value="AL">Alabama</option>
<option data-country="US" value="AK">Alaska</option>
<option data-country="US" value="AZ">Arizona</option>
<option data-country="US" value="AR">Arkansas</option>
<option data-country="US" value="CA">California</option>
<option data-country="US" value="CO">Colorado</option>
<option data-country="US" value="CT">Connecticut</option>
<option data-country="US" value="DE">Delaware</option>
<option data-country="US" value="DC">District Of Columbia</option>
<option data-country="US" value="FL">Florida</option>
<option data-country="US" value="GA">Georgia</option>
<option data-country="US" value="HI">Hawaii</option>
<option data-country="US" value="ID">Idaho</option>
<option data-country="US" value="IL">Illinois</option>
<option data-country="US" value="IN">Indiana</option>
<option data-country="US" value="IA">Iowa</option>
<option data-country="US" value="KS">Kansas</option>
<option data-country="US" value="KY">Kentucky</option>
<option data-country="US" value="LA">Louisiana</option>
<option data-country="US" value="ME">Maine</option>
<option data-country="US" value="MD">Maryland</option>
<option data-country="US" value="MA">Massachusetts</option>
<option data-country="US" value="MI">Michigan</option>
<option data-country="US" value="MN">Minnesota</option>
<option data-country="US" value="MS">Mississippi</option>
<option data-country="US" value="MO">Missouri</option>
<option data-country="US" value="MT">Montana</option>
<option data-country="US" value="NE">Nebraska</option>
<option data-country="US" value="NV">Nevada</option>
<option data-country="US" value="NH">New Hampshire</option>
<option data-country="US" value="NJ">New Jersey</option>
<option data-country="US" value="NM">New Mexico</option>
<option data-country="US" value="NY">New York</option>
<option data-country="US" value="NC">North Carolina</option>
<option data-country="US" value="ND">North Dakota</option>
<option data-country="US" value="OH">Ohio</option>
<option data-country="US" value="OK">Oklahoma</option>
<option data-country="US" value="OR">Oregon</option>
<option data-country="US" value="PA">Pennsylvania</option>
<option data-country="US" value="RI">Rhode Island</option>
<option data-country="US" value="SC">South Carolina</option>
<option data-country="US" value="SD">South Dakota</option>
<option data-country="US" value="TN">Tennessee</option>
<option data-country="US" value="TX">Texas</option>
<option data-country="US" value="UT">Utah</option>
<option data-country="US" value="VT">Vermont</option>
<option data-country="US" value="VA">Virginia</option>
<option data-country="US" value="WA">Washington</option>
<option data-country="US" value="WV">West Virginia</option>
<option data-country="US" value="WI">Wisconsin</option>
<option data-country="US" value="WY">Wyoming</option>
<option data-country="CA" value="">---</option>
<option data-country="CA" value="AB">Alberta</option>
<option data-country="CA" value="BC">British Columbia</option>
<option data-country="CA" value="MB">Manitoba</option>
<option data-country="CA" value="NB">New Brunswick</option>
<option data-country="CA" value="NL">Newfoundland and Labrador</option>
<option data-country="CA" value="NS">Nova Scotia</option>
<option data-country="CA" value="ON">Ontario</option>
<option data-country="CA" value="PE">Prince Edward Island</option>
<option data-country="CA" value="QC">Quebec</option>
<option data-country="CA" value="SK">Saskatchewan</option>
<option data-country="CA" value="NT">Northwest Territories</option>
<option data-country="CA" value="NU">Nunavut</option>
<option data-country="CA" value="YT">Yukon</option>